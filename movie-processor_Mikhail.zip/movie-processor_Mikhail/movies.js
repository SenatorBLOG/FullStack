export const movies = [
  {
    "id": 1,
    "title": "Inception",
    "year": 2010,
    "genre": "Sci-Fi",
    "rating": 8.8,
    "duration": 148
  },
  {
    "id": 2,
    "title": "The Dark Knight",
    "year": 2008,
    "genre": "Action",
    "rating": 9.0,
    "duration": 152
  },
  {
    "id": 3,
    "title": "Interstellar",
    "year": 2014,
    "genre": "Sci-Fi",
    "rating": 8.6,
    "duration": 169
  },
  {
    "id": 4,
    "title": "Parasite",
    "year": 2019,
    "genre": "Thriller",
    "rating": 8.6,
    "duration": 132
  },
  {
    "id": 5,
    "title": "Avengers: Endgame",
    "year": 2019,
    "genre": "Action",
    "rating": 8.4,
    "duration": 181
  },
  {
    "id": 6,
    "title": "Joker",
    "year": 2019,
    "genre": "Drama",
    "rating": 8.5,
    "duration": 122
  },
  {
    "id": 7,
    "title": "The Matrix",
    "year": 1999,
    "genre": "Sci-Fi",
    "rating": 8.7,
    "duration": 136
  },
  {
    "id": 8,
    "title": "Titanic",
    "year": 1997,
    "genre": "Romance",
    "rating": 7.8,
    "duration": 195
  },
  {
    "id": 9,
    "title": "The Godfather",
    "year": 1972,
    "genre": "Crime",
    "rating": 9.2,
    "duration": 175
  },
  {
    "id": 10,
    "title": "Pulp Fiction",
    "year": 1994,
    "genre": "Crime",
    "rating": 8.9,
    "duration": 154
  }
]
