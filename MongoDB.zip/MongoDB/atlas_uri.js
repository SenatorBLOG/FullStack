export const uri = `mongodb+srv://mikhailsenatorov_db_user:qcZFi0KbypAoF1uq
@breathedb.cv0tgsr.mongodb.net/books?retryWrites=true&w=majority&appName=BreatheDB`
export const uri_local= `mongodb://localhost:27017/bookDB`