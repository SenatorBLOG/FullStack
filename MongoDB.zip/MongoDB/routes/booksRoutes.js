import express from "express"
import { Book } from "../models/books.js";
const router = express.Router();



router.get("/api/booksinfo", async (req, res) => {
    try {
        const books = await Book.find();

        res.json(books)
    }
    catch(err){
        res.status(500).json({"error":err.message});
    }
})
router.get("/api/booksinfo/:id", async(req, res)=> {
    const {id} = req.params;
        try {
        const book = await Book.findById(id);
        if(!book) {
            res.status(404).json({"error":"No book is found"})
        }
        res.json(book)
    }
    catch(err){
        res.status(500).json({"error":err.message});
    }
})
router.post("/api/addbook", async (req, res) => {
    try{
        const book = new Book(req.body);
        const saveDoc = await book.save();
        res.json(saveDoc)
    }
    catch(err){
        res.status(500).json({"error":err.message})
        }
});

router.put("/api/updatebook/:id", async (req, res) => {
    const {id} = req.params;
    try{
        const updatedbook = await Book.findByIdAndUpdate(id, req.body,
        {new:true,runValidators:true})
        if(!updatedbook){
            return res.status(404).json({"error":"err"})
        }
        res.json(updatedbook)
    }
    catch(err){
    res.status(500).json({"error":err.message})
     }
    })
    router.delete("/api/deletebook/:id", async (req, res) => {
    const {id} = req.params;
    try{
        const result = await Book.deleteOne({_id:id})
        if(result.deletedCount==0){
         return   res.status(404).json({"error":"error no matching document"})
        
        }
        res.json({"message":`Successfully deleted${result.deletedCount} document`})
        
    }
        catch(err){
    res.status(500).json({"error":err.message})
    }   

})

export default router;