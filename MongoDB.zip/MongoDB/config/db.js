import mongoose from "mongoose"
import {uri,uri_local} from "../atlas_uri.js"

export const connectDB = async ( ) => {
    try{
        await mongoose.connect(uri);
        console.log(`Connected to MpngoDb`)
    }
    catch(err){
        console.log(`Connection failed ${err}`)
        process.exit(1)
    }
}